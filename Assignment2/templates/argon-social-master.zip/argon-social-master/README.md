<h1 align="center"> Argon Social </h1> <br>
<p align="center">
  <a href="https://artmin96.github.io/argon-social/" target="_blank">
    <img alt="Argon Social" title="Argon Social" src="https://github.com/ArtMin96/argon-social/blob/master/assets/images/logo-256x256.png" width="450">
  </a>
</p>

<p align="center">
  Watch DEMO - v0.2
</p>

<p align="center">
  <a href="https://artmin96.github.io/argon-social/" target="_blank">
    Argon Social Network Design System
  </a>
</p>

<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->
## Pages

- Sign Up
- Sign In
- User Profile
- Newsfeed
- Messenger
- Settings - Basic info, contact info, password, location

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

## Screenshot

<p align="center">
  <img src = "https://github.com/ArtMin96/argon-social/blob/master/screenshots/Sign-in.png" width=200>
  <img src = "https://github.com/ArtMin96/argon-social/blob/master/screenshots/Sign-up.png" width=200>
  <img src = "https://github.com/ArtMin96/argon-social/blob/master/screenshots/Newsfeed.png" width=200>
  <img src = "https://github.com/ArtMin96/argon-social/blob/master/screenshots/Profile.png" width=200>
  <img src = "https://github.com/ArtMin96/argon-social/blob/master/screenshots/Messenger.png" width=200>
  <img src = "https://github.com/ArtMin96/argon-social/blob/master/screenshots/Settings-basic-info.png" width=200>
  <img src = "https://github.com/ArtMin96/argon-social/blob/master/screenshots/Settings-password.png" width=200>
  <img src = "https://github.com/ArtMin96/argon-social/blob/master/screenshots/Settings-location.png" width=200>
</p>